                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2773325
HCSR04 5V to 3.3V Converter by teinturman is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This little box allows to connect a HCSR04 distance sensor to  GPIO pins of a Raspberry pi without soldering anything.
As no soldering skills are required , this is ideal for classroom initiation... 

* Why do you need this adapter : 
 - The Raspberry pi has .3V GPIO, and the HCSR04 input is 5V. 
 - If you want to connect a HCSR04 sensor to a raspberry pi, you really need to add 2 résistors to divide the voltage. A 1K resistor and a 2K resistor. This adapter is a  way to achieve this, without the need to solder anything.

* What you will need
 - a female / Female  dupont cable with 4 pins connectors.
 - 3 screws , ( Please check the photo of the reference for the screws)
 - 1 resistor 1K
 - 1 Resistor 2K
 -  The STL parts, ( you will need 3* Block.stl )


* How to make it  : 
 - Prepare the résistors like in  the first photo.
 - Use the box , screws and block to lock the resistors ( by screwing the little block on the wires)

* How to connect it : 
 - connect the dupont cable sensor side to the HCSR04.
 - connect the  board side cables to the Raspberry pi. 
 - Check my recommended SONAR allocation PI PINS. ( Check the 2 Powerpoint slides) I use this allocation with 4 pins female female dupont cables where i reorder the wires in the connectors to match each SLOT.


* how to test it : 
  you can find many python examples to test HCSR04 devices on github.

This is part of a wider project that i am preparing since a year now, and which is getting closer to be released ! 

Follow me ! :-)